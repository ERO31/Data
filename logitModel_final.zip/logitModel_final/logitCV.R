
library(ROCR)

set.seed(8051)

####################################################################

data.train = read.csv("pp_train.csv")
data.train = na.omit(data.train)
data.train = data.train[data.train$ni.age < 100,]

####################################################################

# for calculating err

misclassification = function(obs,pred){
  temp = ifelse( obs == pred, 0, 
                 ifelse(obs == 1, 5, 1) )
  mean(temp)
}

####################################################################

err = numeric(100)
cstat = numeric(100)
n.data = nrow(data.train)

for (i in 1:100){
  
  train = sample(1:n.data)[1:round(n.data*0.2)]
  
  # the best logit model M0
  logit0 = glm(cancel ~ 
                 factor(claim.ind) + sales.channel + credit + factor(zip.code) + 
                 n.adults * n.children + tenure + len.at.res * ni.age + ni.marital.status,
              data = data.train[train,], family = binomial(link = "logit") )
  
  pred0.p = predict(logit0, data.train[-train,], type = "response")
  # pred1.p = predict(logit1, data.train[-train,], type = "response")
  # pred2.p = predict(logit2, data.train[-train,], type = "response")
  
  # pred.p.vote = matrix(0, nrow = nrow(data.train[-train,]), ncol = 100)
  # 
  # for (j in 1:100) {
  #   boostrap = sample(train, replace = T)
  #   
  #   logit = glm(cancel ~ 
  #                 factor(claim.ind) + sales.channel + credit + factor(zip.code) + 
  #                 n.adults * n.children + tenure + len.at.res * ni.age + ni.marital.status,
  #               data = data.train[boostrap,], family = binomial(link = "logit") )
  #   
  #   pred.p.vote[,j] = predict(logit, data.train[-train,], type = "response")
  #   
  # }
  # 
  # pred1.p = apply(pred.p.vote, 1, mean)
  
  input0 = prediction(pred0.p, data.train[-train,]$cancel)
  auc0 = performance(input0, "auc")
  # input1 = prediction(pred1.p, data.train[-train,]$cancel)
  # auc1 = performance(input1, "auc")
  
  cstat[i] = unlist(auc0@y.values) #- unlist(auc1@y.values)
  
  pred0.c = ifelse(pred0.p > 1/6,1,0)
  # pred1.c = ifelse(pred1.p > 1/6,1,0)
  # pred3.c = ifelse(pred0.p > 1/6 & pred1.p > 1/6, 1, 0)
  
  err[i] = with(data.train[-train,], misclassification(cancel,pred0.c)) #- with(data.train[-train,], misclassification(cancel,pred1.c))
  
}

mean(err)
mean(cstat)

#####################################################################

