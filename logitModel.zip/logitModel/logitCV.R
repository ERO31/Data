
library(ROCR)

set.seed(8051)

#######################################################


data.train = read.csv("pp_train.csv")
data.train = na.omit(data.train)
data.train = data.train[data.train$ni.age < 100,]


#######################################################

# for calculating err

misclassification = function(obs,pred){
  temp = ifelse( obs == pred, 0, 
                 ifelse(obs == 1, 5, 1) )
  mean(temp)
}



#######################################################

err = numeric(100)
cstat = numeric(100)
n.data = nrow(data.train)

for (i in 1:100){
  
  train = sample(1:n.data)[1:round(n.data*0.9)]
  
  # the best logit model M0
  logit0 = glm(cancel ~ 
                 factor(claim.ind) + sales.channel + credit + factor(zip.code) + 
                 n.adults * n.children + tenure + len.at.res * ni.age + ni.marital.status,
              data = data.train[train,], family = binomial(link = "logit") )
  
  # the model M1 for first submission
  logit1 = glm(formula = cancel ~ 
                 factor(claim.ind) + sales.channel + credit + factor(zip.code) + dwelling.type + coverage.type + 
                 n.adults*n.children + (tenure + len.at.res) * ni.age + premium + ni.marital.status,
               family = binomial(link = "logit"), data = data.train[train, ])
  
  pred0 = predict(logit0, data.train[-train,], type = "response")
  pred1 = predict(logit1, data.train[-train,], type = "response")
  
  input0 = prediction(pred0, data.train[-train,]$cancel)
  auc0 = performance(input0, "auc")
  input1 = prediction(pred1, data.train[-train,]$cancel)
  auc1 = performance(input1, "auc")
  
  cstat[i] = unlist(auc0@y.values) #- unlist(auc1@y.values)
  
  pred0 = ifelse(pred0 > 1/6,1,0)
  pred1 = ifelse(pred1 > 1/6,1,0)
  
  err[i] = with(data.train[-train,], misclassification(cancel,pred0)) #- with(data.train[-train,], misclassification(cancel,pred1))
  
}

mean(err)
mean(cstat)

#####################################################################


