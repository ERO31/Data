############################################################################
#################### 1. Model construction (code run once) #################
############################################################################

library(caret)
library(xgboost)
library(plyr)
library(ggplot2)

# Get Travelers trainin data.
train <- read.csv('./data/pp_train_v4b_zip4_mb.csv')
train$cancel <- factor(train$cancel)
levels(train$cancel) <- make.names(levels(factor(train$cancel)))
N = length(train)

# Split training data further 80/20 into training and validation set.
set.seed(8051)
idx <- createDataPartition(y=train$cancel,p=0.8, list=FALSE)

# Create a watchlist for xgBoost, which is used to stop boosting rounds
# and prevent overfitting.
dtrain <- xgb.DMatrix(data = as.matrix(train[idx,3:N]), label = train[idx,2])
dtest <- xgb.DMatrix(data = as.matrix(train[-idx,3:N]), label = train[-idx,2])
watchlist <- list(train=dtrain, test=dtest)

# Hyper-parameter search. First, tune tree depth.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.1,
    max_depth = c(2, 4, 6, 8, 10),
    gamma = 0,
    colsample_bytree = 1,
    min_child_weight = 1,
    subsample = 1
)
# Best depth = 6 (CV AUC = 0.6959998)

# Tune min_child_weight.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.1,
    max_depth = 6,
    gamma = 0,
    colsample_bytree = 1,
    min_child_weight = c(7,7.25,7.5),
    subsample = 1
)
# Best min_child_weight = 7.25 (CV AUC = 0.6999421)

# Tune subsample.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.1,
    max_depth = 6,
    gamma = 0,
    colsample_bytree = 1,
    min_child_weight = 7.25,
    subsample = 0.5
)
# Best sub_sample = 0.5 (CV AUC = 0.7006593).

# Tune colsample_bytree.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.1,
    max_depth = 6,
    gamma = 0,
    colsample_bytree = c(0.5,0.6,0.7,0.8,0.9,1),
    min_child_weight = 7.25,
    subsample = 0.5
)
# Best colsample_bytree = 1.0 (AUC = 0.7008876)

# Redo max_depth.
xgb_grid = expand.grid(
    nrounds = 100,
    eta = 0.1,
    max_depth = c(5,6,7),
    gamma = 0,
    colsample_bytree = 1.0,
    min_child_weight = 7.25,
    subsample = 0.5
)
# max_depth = 6 is still the best (CV AUC = 0.6985546).

# Tune eta.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = c(0.05,0.06,0.07,0.08,0.09),
    max_depth = 6,
    gamma = 0,
    colsample_bytree = 1.0,
    min_child_weight = 7.25,
    subsample = 0.5
)
# The best eta is 0.08 (CV AUC = 0.7021672)

# Tune nrounds given eta fixed at by observing the stopping rounds.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.08,
    max_depth = 6,
    gamma = 0,
    colsample_bytree = 1.0,
    min_child_weight = 7.25,
    subsample = 0.5
)
# On this run, CV AUC = 0.7000576. Best iterations ranged from 4 to 39, so
# I will set nrounds at 40 in the futre.

# But first, try adjusting gamma to see if there is any benefit.
xgb_grid = expand.grid(
    nrounds = 1000000,
    eta = 0.08,
    max_depth = 6,
    gamma = c(0.1,0.5,1),
    colsample_bytree = 1.0,
    min_child_weight = 7.25,
    subsample = 0.5
)
# best gamma = 0.1 (CV AUC = 0.7005262)

# Finally, fine-tune (colsample_bytree, min_child_weight, subsample)
xgb_grid = expand.grid(
    nrounds = 100,
    eta = 0.08,
    max_depth = 6,
    gamma = 0.1,
    colsample_bytree = c(0.98,0.99,1.0),
    min_child_weight = c(7.15,7.25,7.35),
    subsample = c(0.5,0.56,0.57)
)
# The final values used for the model were nrounds = 100, max_depth = 6, 
# eta = 0.08, gamma = 0.1, colsample_bytree = 1, min_child_weight = 7.35
# and subsample = 0.5 (CV AUC = 0.7016982).

# Define parameters for caret's train function.
xgb_trcontrol = trainControl(
    method = "repeatedcv",
    number = 10,
    repeats = 20,
    verboseIter = TRUE,
    returnData = FALSE,
    returnResamp = "all",                                                        # save losses across all models
    classProbs = TRUE,                                                           # set to TRUE for AUC to be computed
    summaryFunction = twoClassSummary,
    allowParallel = TRUE
)

# Code for training the xg boosted tree model.
xgb.tree = train(
    x = as.matrix(train[idx,3:N]),
    y = as.factor(train$cancel[idx]),
    trControl = xgb_trcontrol,
    tuneGrid = xgb_grid,
    method = "xgbTree",
    metric = 'ROC',
    early_stopping_rounds=50,
    watchlist = watchlist
)
xgb.tree

#############################################################################
################### Train final, tuned model (code run once) ################
#############################################################################

# best parameters from tuning
xgb_grid = expand.grid(
    nrounds = 40,
    eta = 0.08,
    max_depth = 6,
    gamma = 0.1,
    colsample_bytree = 1,
    min_child_weight = 7.35,
    subsample = 0.5
)

# Define parameters for caret's train function, in particular 10-fold
# CV replicated 100 times, in order to get a (hopefully), well converged
# AUC measurement.
xgb_trcontrol = trainControl(
    method = "repeatedcv",
    number = 10,
    repeats = 1,
    verboseIter = TRUE,
    returnData = FALSE,
    returnResamp = "all",                                                        # save losses across all models
    classProbs = TRUE,                                                           # set to TRUE for AUC to be computed
    summaryFunction = twoClassSummary,
    allowParallel = TRUE
)

# Train final model full training data. I noted late here that I needed
# to add <objective = 'binary:logistic'> to the function call of train
# to be able to predict class probabilities from the model. I am not
# sure means tuning needs to go back and re-adjusted, but in any case
# it is worth noting that I may have to re-tune.
set.seed(8051)
xgb.tree = train(
    x = as.matrix(train[,3:N]),
    y = as.factor(train$cancel[]),
    trControl = xgb_trcontrol,
    tuneGrid = xgb_grid,
    method = "xgbTree",
    metric = 'ROC',
    objective = 'binary:logistic'
)
xgb.tree
# Final averaged AUC =  0.7084028.

# Save model to disk.
save(xgb.tree, file = "./models/best_xgb-tree_model_v0.rda")

#############################################################################
######### Start here to load model from disk and make predictions ###########
#############################################################################

# Load model and data.
train <- read.csv('./data/pp_train_v4b_zip4_mb.csv')
test <- read.csv('./data/pp_test_v4b_zip4_mb.csv')
load("./models/best_xgb-tree_v0.rda")

# Predict on training and test sets.
train.prediction = predict(xgb.tree, newdata = train, type = 'prob')[,2]
test.prediction = predict(xgb.tree, newdata = test, type = 'prob')[,2]

# Save predictions.
save(train.prediction, file = "./models/best_xgb-tree_train_pred_v0.rda")
save(test.prediction, file = "./models/best_xgb-tree_test_pred_v0.rda")