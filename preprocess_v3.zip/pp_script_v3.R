library(forecast)
library(RANN)
library(caret)
library(e1071)
library(MXM)

##########################################################################
######################## Helper functions. ###############################
##########################################################################

# This functions removes observations with response -1.
remove.weird.response <- function(x) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    # Returns: a dataframe.
    return (subset(x, cancel != -1))
}

# This functions reorders columns so numerical, binary, and factor data 
# are clustered together.
reorder <- function(x) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    # Returns: a dataframe.
    return (x[,c(18,17,15,1,3,4,7,11,14,2,6,5,8,9,10,12,13,16,17,18)])
}

# This function replaces zip code by it's first n digits, providing a 
# regiona; clustering of zip codes.
cluster.zip <- function(x,n=1) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    #         n, a cluster level paramter for zip codes between 1 and 5.
    # Returns: a dataframe.    
    if (n == 1) {x$zip.code <- factor(floor(x$zip.code/10000))}
    else if (n == 2) {x$zip.code <- factor(floor(x$zip.code/1000))}
    else if (n == 3) {x$zip.code <- factor(floor(x$zip.code/100))}
    else if (n == 4) {x$zip.code <- factor(floor(x$zip.code/10))}
    else if (n == 5) { }
    else throw('n must be between 1 and 5')
    return (x)
}

# This function converts factor data in the travelers train and test
# dataframes to labeled full rank dummy variables.
my.factor.to.dummy <- function(train, test = NULL) {
    # Inputs: train and test, travelers insurance train and test 
    #         dataframes.
    # Returns: a named list of two dataframes.
    dummy.obj <- dummyVars(~., train[,10:18], fullRank = T)
    train <- cbind(train[,1:9],predict(dummy.obj, train[,10:18]))
    test <- cbind(test[,1:9],predict(dummy.obj, test[,10:18]))
    return(list(train = train, test = test))
}

# This function contains the full data preprocessing pipeline.
my.preprocess = function(train,test, n = 5, p = 0) {
    
    # Inputs: train - dataframe of travelers training insurance data
    #         test  - dataframe of travelers test insurance data 
    #         n     - zip code cluster parameter (between 1 and 4 only)
    #         p     - p value cutoff for Min-Max Markov blanket feature
    #                 selection algoritm (between 0 and 1 only)
    #        
    # Return: a named list of two pre-processed dataframes (train and
    #         test)
    
    # Step 1. Remove weird -1 responses.
    train <- remove.weird.response(train)
    
    # Step 2. Change test$delling$type = 'Landlord' -> 'Tenant' to 
    # conform with the training data.
    test$dwelling.type[test$dwelling.type == 'Landlord'] <- 'Tenant'
    test <- droplevels(test)
    
    # Step 3. Reorder columns so numeric and factor are next to each 
    # other. This helps with converting to dummy variables later on.
    train <- reorder(train)
    test <- reorder(test)
    
    # Step 4. Cluster by zip code.
    train <- cluster.zip(train,n)
    test <- cluster.zip(test,n)
    
    # Step 5. Convert year from nominal to orignal and shift to be near
    # zero.
    shift <- -2015
    train$year <- train$year + shift
    test$year <- test$year + shift
    
    # Step 6. Convert factors to dummy variables, and also 
    # reorder labels at front of dataframe for ease of indexing later on.
    result <- my.factor.to.dummy(train,test)
    train <- result$train
    test <- result$test
    
    # Step 6. Center and scale, perform Box Cox transformation, 
    # and impute NAs according to 7 nearest neighbors.
    l = length(train)
    caret.object <- preProcess(as.matrix(train[,4:l]), 
                               method=c("bagImpute"))
    caret.object <- preProcess(as.matrix(train[,4:l]), 
                               method=c("BoxCox","center","scale",
                                        "knnImpute"),k=7)
    train <- predict(caret.object,train)
    if (!is.null(test)) {test = predict(caret.object, test) }
    
    # Step 8. Perform Markov blanket variable selection.
    selected <- mmmb(train$cancel, temp.train, threshold = p, 
                     ncores = 2) + 2
    index = c(1,2,selected)
    train <- train[,index]
    test <- train[,test]
    
    return(list(train = train, test = test))
}


##########################################################################
############### Preprocessing script #####################################
##########################################################################

col.classes = c('integer','factor','integer',
                'integer','factor','factor','numeric','factor',
                'factor','factor','numeric','factor','factor',
                'numeric','integer','integer','integer','integer')

train <- read.csv('train.csv', colClasses = col.classes)
test <- read.csv('test.csv', colClasses = col.classes)

# Zip codes clustered by n = 4, no Markov blanket variable selection.
pp.result_n4 = my.preprocess(train, test, n = 4, p = 0)
pp.train_n4 <- pp.result$train_n4
pp.test_n4 <- pp.result$test_n4
write.csv(pp.train_n4, file = "pp_train_v4_n4.csv", row.names = F)
write.csv(pp.test_n4, file = "pp_test_v4_n4.csv", row.names = F)

# Zip codes clustered by n = 5 (full zip), no Markov blanket variable 
# selection.
pp.result_n5 = my.preprocess(train,test)
pp.train_n5 <- pp.result$train_n4
pp.test_n5 <- pp.result$test_n4
write.csv(pp.train_n5, file = "pp_train_v4_n5.csv", row.names = F)
write.csv(pp.test_n5, file = "pp_test_v4_n5.csv", row.names = F)

# Zip codes clustered by n = 4, Markov blanket variable selection at 
# p = 0.15.
pp.result_n4 = my.preprocess(train,test)
pp.train_n4 <- pp.result$train_n4
pp.test_n4 <- pp.result$test_n4
write.csv(pp.train_n4, file = "pp_train_v4_n4.csv", row.names = F)
write.csv(pp.test_n4, file = "pp_test_v4_n4.csv", row.names = F)

# Zip codes clustered by n = 5 (full zip), Markov blanket variable 
# selection at p = 0.15.
pp.result_n5 = my.preprocess(train,test)
pp.train_n5 <- pp.result$train_n4
pp.test_n5 <- pp.result$test_n4
write.csv(pp.train_n5, file = "pp_train_v4_n5.csv", row.names = F)
write.csv(pp.test_n5, file = "pp_test_v4_n5.csv", row.names = F)

