library(forecast)
library(RANN)
library(caret)
library(e1071)
library(MXM)

##########################################################################
######################## Helper functions. ###############################
##########################################################################

# This functions removes observations with response -1.
remove.weird.response <- function(x) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    # Returns: a dataframe.
    return (subset(x, cancel != -1))
}

# This functions reorders columns so numerical, binary, and factor data 
# are clustered together.
reorder <- function(x) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    # Returns: a dataframe.
    return (x[,c(18,17,15,1,3,4,7,11,14,2,6,5,8,9,10,12,13,16)])
}

# This function replaces zip code by it's first n digits, providing a 
# regiona; clustering of zip codes.
cluster.zip <- function(x,n=1) {
    # Inputs: x, dataframe of travelers insurance train or test data.
    #         n, a cluster level paramter for zip codes between 1 and 5.
    # Returns: a dataframe.
    idx <- !is.na(x$zip.code)
    if (n == 1) {x$zip.code[idx] <- floor(x$zip.code[idx]/10000)}
    else if (n == 2) {x$zip.code[idx] <- floor(x$zip.code[idx]/1000)}
    else if (n == 3) {x$zip.code[idx] <- floor(x$zip.code[idx]/100)}
    else if (n == 4) {x$zip.code[idx] <- floor(x$zip.code[idx]/10)}
    else if (n == 5) { }
    else throw('n must be between 1 and 5')
    x$zip.code <- addNA(factor(x$zip.code))
    return (x)
}

# This function converts factor data in the travelers train and test
# dataframes to labeled full rank dummy variables.
my.factor.to.dummy <- function(train, test = NULL) {
    # Inputs: train and test, travelers insurance train and test 
    #         dataframes.
    # Returns: a named list of two dataframes.
    dummy.obj <- dummyVars(~., train[,10:18], fullRank = T)
    train <- cbind(train[,1:9],predict(dummy.obj, train[,10:18]))
    test <- cbind(test[,1:9],predict(dummy.obj, test[,10:18]))
    return(list(train = train, test = test))
}

# This function places NAs in factor variables in their own level.
refactor.NAs <- function(x) {
    # Inputs: x, a dataframe of travelers insurance data
    # Returns: dataframe
    L = length(x)
    for (i in 1:L) {
        if (is.factor(x[,i])) {
            x[,i] <- addNA(x[,i])
        }
    }
    return(x)
}

# This function replaces NA's in numerical variables with -999 .
sink.NAs <- function(x) {
    # Inputs: x, a dataframe of travelers insurance data
    # Returns: dataframe
    L = length(x)
    labs <- sapply(x, typeof)
    for (i in 1:L) {
        if (labs[i] == 'numeric' || labs[i] == 'integer' || 
            labs[i] == 'double') {
            x[is.na(x[,i]),i] <- -999
        }
    }
    return(x)
}

# This function contains the full data preprocessing pipeline.
my.preprocess = function(train,test, n = 5, p = NULL) {
    
    # Inputs: train - dataframe of travelers training insurance data
    #         test  - dataframe of travelers test insurance data 
    #         n     - zip code cluster parameter (between 1 and 4 only)
    #         p     - p value cutoff for Min-Max Markov blanket feature
    #                 selection algoritm (between 0 and 1 only)
    #        
    # Return: a named list of two pre-processed dataframes (train and
    #         test)
    
    # Step 1. Remove weird -1 responses.
    train <- remove.weird.response(train)
    
    # Step 2. Change test$dwelling.type = 'Landlord' -> 'Tenant' in order 
    # to conform with the training data.
    test$dwelling.type[test$dwelling.type == 'Landlord'] <- 'Tenant'
    test <- droplevels(test)

    # Step 3. Reorder columns so numeric and factor are next to each
    # other. This helps with converting to dummy variables later on.
    train <- reorder(train)
    test <- reorder(test)
    
    # Step 4. For each factor variable, set missing values to their own
    # 'NA' level.
    train <- refactor.NAs(train)
    test <- refactor.NAs(test)

    # Step 5. Cluster by zip code.
    train <- cluster.zip(train,n)
    test <- cluster.zip(test,n)

    # Step 6. Convert year from nominal to orignal and shift to be near
    # zero.
    shift <- -2015
    train$year <- train$year + shift
    test$year <- test$year + shift

    # Step 7. Center and scale, perform Box Cox transformation,
    # and impute NAs according to 5 nearest neighbors.
    caret.object <- preProcess(as.matrix(train[,4:9]),
                    method = c("center","scale","BoxCox","knnImpute"))
    train <- predict(caret.object,train)
    test <- predict(caret.object,test)
    
    # Step 8. Set continuous variable missing values to -999. 
    # Not implemented as this messes with Bayesian inference.
    # train <- sink.NAs(train)
    # test <- sink.NAs(test)
    
    # Step 9. Convert factors to dummy variables.
    result <- my.factor.to.dummy(train,test)
    train <- result$train
    test <- result$test
    
    # Step 10. Perform Markov blanket variable selection.
    if (!is.null(p)) {
        l = length(train)
        mb.object <- mmmb(train$cancel, train[,3:l], threshold = p,
                          ncores = 2)
        print(mb.object$mb)
        index = c(1,2,mb.object$mb+2)
        train <- train[,index]
        test <- test[,index]
    }

    return(list(train = train, test = test))
}

##########################################################################
############### Preprocessing script #####################################
##########################################################################

col.classes = c('integer','factor','integer',
                'integer','factor','factor','numeric','factor',
                'factor','factor','numeric','factor','factor',
                'numeric','integer','integer','integer','integer')

train <- read.csv('./data/train.csv', colClasses = col.classes)
test <- read.csv('./data/test.csv', colClasses = col.classes)

# Zip codes clustered by n = 1, no Markov blanket variable selection.
pp.result = my.preprocess(train, test, n = 1)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip1.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip1.csv", row.names = F)
# print(labels(pp.train)[[2]])

# Zip codes clustered by n = 4, no Markov blanket variable selection.
pp.result = my.preprocess(train, test, n = 4)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip4.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip4.csv", row.names = F)

# Zip codes clustered by n = 5 (full zip), no Markov blanket variable
# selection.
pp.result = my.preprocess(train,test, n = 5)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip5.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip5.csv", row.names = F)

# Zip codes clustered by n = 1, Markov blanket variable selection at
# p-value cutoff of 0.15.
pp.result = my.preprocess(train,test, n = 1, p = 0.15)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip1_mb.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip1_mb.csv", row.names = F)

# Zip codes clustered by n = 4, Markov blanket variable selection at
# p-value cutoff of 0.15.
pp.result = my.preprocess(train,test, n = 4, p = 0.15)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip4_mb.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip4_mb.csv", row.names = F)

# Zip codes clustered by n = 5, Markov blanket variable selection at
# p-value cutoff of 0.15.
pp.result = my.preprocess(train,test, n = 5, p = 0.15)
pp.train <- pp.result$train
pp.test <- pp.result$test
write.csv(pp.train, file = "./data/pp_train_v4b_zip5_mb.csv", row.names = F)
write.csv(pp.test, file = "./data/pp_test_v4b_zip5_mb.csv", row.names = F)

# ##########################################################################
# ###### 4. Test case: 1st order Logistic regression without ###############
# ###### cross-validation. #################################################
# ##########################################################################
# train <- read.csv('pp_train_v4b_zip1.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)
# 
# train <- read.csv('pp_train_v4b_zip4.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)
# 
# train <- read.csv('pp_train_v4b_zip5.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)
# 
# train <- read.csv('pp_train_v4b_zip1_mb.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)
# 
# train <- read.csv('pp_train_v4b_zip4_mb.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)
# 
# train <- read.csv('pp_train_v4b_zip5_mb.csv')
# L = ncol(train)
# model <- glm(cancel ~ ., data = train[,2:L], family = binomial)
# y.hat <- predict(model, type = 'response')
# y.hat.test <- predict(model, type = 'response')
# proportion <- 1 - mean(train$cancel)
# cutoff <- quantile(y.hat, proportion)
# training.prediction <- (y.hat > cutoff)*1
# training.accuracy = mean(train$cancel == training.prediction)
# print(training.accuracy)